"""Persistent host profile settings. No transport or native library is imported."""
import json
import os
from pathlib import Path
import uuid

from .errors import CyToolError

PROFILES = ('free', 'local_controlled', 'token_only', 'protected_access')


def configure(root, profile=None):
    """Migrate an unset choice to Free; preserve explicit choices and other settings."""
    path = Path(root) / 'communication.json'
    try:
        value = json.loads(path.read_text(encoding='utf-8-sig'))
    except FileNotFoundError:
        value = {}
    except (OSError, ValueError) as exc:
        raise CyToolError('ConfigurationError', 'Cannot read communication.json') from exc
    if not isinstance(value, dict) or type(value.get('schemaVersion', 1)) is not int or value.get('schemaVersion', 1) != 1:
        raise CyToolError('ConfigurationError', 'Unsupported communication settings')
    selected = profile if profile is not None else value.get('accessProfile')
    if selected is None or selected == '':
        selected = 'free'
    if selected not in PROFILES:
        raise CyToolError('ConfigurationError', 'Unknown local access profile')
    updated = {**value, 'schemaVersion': 1, 'accessProfile': selected}
    if updated != value:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
        try:
            temp.write_text(json.dumps(updated, indent=2) + '\n', encoding='utf-8')
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)
    return updated
