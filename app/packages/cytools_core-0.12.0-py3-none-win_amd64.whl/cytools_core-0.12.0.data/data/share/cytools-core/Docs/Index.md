# Documentation CyToolsCore

## Pour créer un Tool

- [Guide IA](AgentGuide.md) : contrat de travail, configuration et définition de terminé.
- [Prompt prêt à copier](AgentPrompt.md).
- [Premier CyTool](CreatingYourFirstCyTool.md) : installation et commandes.

## Standard et architecture

- [Vue d'ensemble](Overview.md), [architecture](Architecture.md), [manifest](ToolManifest.md).
- [Opérations](Operations.md), [paramètres](Parameters.md), [sorties](Outputs.md).
- [Protocole](Protocol.md), [versions](Versioning.md), [erreurs](ErrorModel.md).

## Exécution

- [Jobs](Jobs.md), [multi-client](MultiClient.md), [scheduler](Scheduler.md), [événements](Events.md).
- [Ressources](Resources.md), [plateformes](Platforms.md), [modèles](Models.md), [workers](Workers.md).
- [Dépendances](Dependencies.md), [téléchargements](Downloads.md).
- [Transports](Transports.md), [MCP](MCP.md), [communication native](NativeCommunication.md).

## Validation et limites

- [Fonctionnalités livrées](ImplementationStatus.md).
- [Résultats de validation](Validation.md).
- [Licence MIT et redistribution](Licensing.md).

## Mettre à jour un produit existant

- [Migration des logiciels et plugins utilisant les SDK](UpdateExistingProducts.md).


## Profils MCP locaux — SDK 0.12.0

Lire [LocalAccess.md](LocalAccess.md). Intégrer CyMCPSDK au commit
`34d4bcae126bc83d1a2925b5047dac36e3d09d92` ou un descendant compatible vérifié.
Free est le choix initial sans jeton sur 127.0.0.1, avec toutes les opérations
enregistrées et validation conservée. Migrer les choix absents vers Free ; garder
les profils explicites Local contrôlé, Jeton seul et Protégé. Ne pas augmenter les
droits des clients CLI/embarqués ou des identités protégées lors de cette migration.
Le profil HTTP est une décision de l’hôte et les paramètres métier ne choisissent
jamais cette identité ou ce profil. Tester lecture/écriture sans jeton et refus de
Protégé sans jeton, puis les parcours CLI/chat existants, sans workflow GitHub.
