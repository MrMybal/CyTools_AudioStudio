# Prompt prêt à fournir à une IA

## Prompt court pour un nouveau Tool

```text
Crée CyTools_<NOM> dans un nouveau sous-dossier <TOOLS_ROOT>/CyTools_<NOM>.
Fonction : <DESCRIPTION COURTE>.
Suis toutes les instructions de <SDK_ROOT>\Docs\AgentPrompt.md,
ainsi que les documents qu'il référence. Ne modifie pas les autres Tools.
```

## Instructions complètes de création

Remplacer les champs entre chevrons. Les documents cités sont obligatoires.

```text
Crée une application CyTools autonome nommée <NOM>, ID <ID>, dans <TOOLS_ROOT>/<NOM>.
Fonction attendue : <DESCRIPTION DU MODÈLE/OUTIL, ENTRÉES, SORTIES ET OPTIONS>.
Sources officielles : <URL DU MOTEUR, PAGE DU MODÈLE, DÉPÔT GITHUB DU TOOL SI DISPONIBLE>.

SDK local : <SDK_ROOT>. Lis d’abord AGENTS.md, README.md,
Docs/AgentGuide.md, Docs/StandaloneDelivery.md, Docs/Architecture.md et
Docs/ImplementationStatus.md. Utilise cytools new --desktop ; ne copie jamais le runtime.

Livre une racine épurée : <NOM>.exe, lanceur Linux, LISEZ-MOI.md, app/, data/, runtime/.
Range code, manifeste, tests et scripts dans app ; modèles, entrées, jobs, réglages et
logs dans data ; environnements privés, sources de moteurs, téléchargements et versions
dans runtime. Nettoie les artefacts de développement avant livraison sans supprimer de données.

L’exécutable Windows doit ouvrir directement une vraie interface Dear ImGui.
L'interface est en anglais par defaut et entierement disponible en francais.
Applique Docs/Localization.md : onglet Options avec langue persistante, theme,
taille du texte et licences du Tool, du moteur, des modeles et des dependances,
avec liens officiels. Ne suppose aucun droit pour une licence non renseignee.
Ajoute Save/Load configuration et Autosave on generation dans Options, en appliquant
Docs/GenerationConfigurations.md : JSON versionne, parametres exacts reutilisables
par une IA, aucun secret, chargement sans execution automatique.
Applique Docs/SharedInstallation.md : cache local/partagé configurable, Python privé,
CUDA Toolkit partagé explicitement sélectionné et version vérifiée, états structurés
pour l'IA en cas de connexion/licence nécessaire. Ne déplace aucun modèle existant.
Distribue sans poids, caches et gros environnements ; guide leur installation au premier lancement.
Toutes les capacités annoncées doivent être utilisables dans cette interface : sélection
entrée/modèle/backend, réglages usuels et avancés, génération, progression réelle,
annulation, erreurs, diagnostic et accès/aperçu des résultats. Pas de JSON à éditer pour
l’usage normal. CLI et MCP utilisent le même runtime et les mêmes schémas.
Pour tout Tool qui produit/modifie un mesh, applique Docs/MeshViewer.md et utilise
--desktop --mesh-viewer : vrai viewport 3D, ouverture automatique du résultat, navigation
souris/clavier en orbite et libre, inspection rapprochée, scènes, studio trois points
et soleil, matériaux PBR. Une image fixe ou un lanceur externe ne suffit pas.

Ajoute un écran d’installation des modèles : état, taille, source, licence, boutons
Télécharger/Reprendre/Réparer/Annuler. Si autorisation requise, fournir instructions et
liens officiels, puis une connexion locale sécurisée. L’utilisateur accepte lui-même la
licence. Aucun jeton dans argv, paramètres de jobs, manifeste ou logs. Vérifie les fichiers
et prépare les modèles auxiliaires ; n’annonce pas un modèle installé avant contrôle.

Ajoute les mises à jour GitHub de l’application et du moteur en les distinguant des poids.
Source configurée, vérification et téléchargement automatiques optionnels, staging,
contrôles de version/hash/ABI/archives, activation hors génération, sauvegarde et retour
arrière. Préserve data. Si le dépôt du Tool n’existe pas, rends-le configurable et indique
cette limite ; n’invente ni URL, ni release, ni test réussi.

Conserve jobs, identités authentifiées, workspaces, réservations et annulation du SDK.
Isole le modèle dans un worker ; libère les ressources seulement après son arrêt réel.
Aucune dépendance ImGui ou IA dans le Core. Crée les environnements à leur chemin final.

Teste le lanceur et les écrans ImGui, un traitement réel et ses sorties, l’installation,
les erreurs d’accès, l’annulation, l’isolation, le MCP, les mises à jour et leur rollback.
Distingue Windows/Linux exécutés, tests avec fixtures et fonctions encore non vérifiées.
Un scaffold CLI/MCP n’est pas une livraison terminée. Livre le dossier rangé, un guide
court et les preuves dans data/reports. Décris honnêtement les prérequis du runtime.
```
# Exigences complémentaires obligatoires

Appliquer `Docs/StandaloneDiagnosticsAndModels.md` : journal intégré sélectionnable
et copiable, résolution vidéo prévue/réelle visible, ajout de modèles locaux compatibles,
LoRA avec intensités lorsque le moteur sait les charger, et sélection CPU/GPU/Auto
avec ressources et exécution cohérentes. Conserver ces sélections dans Save/Load/Autosave.


Lire [FullOperationAccess.md](FullOperationAccess.md) : inventaire des capacités natives, parité complète des options métier entre IA et standalone, contrats de sorties composables et preuves de validation. Un formulaire simplifié ne limite pas le contrat du Tool.

Appliquer aussi `Docs/Scheduler.md` (SDK 0.10.0 ou ultérieur) : déclarer les groupes
`exclusiveGroups` des opérations qui doivent partager un GPU sans concurrence, utiliser
la file du SDK et vérifier les priorités, les délais et l'annulation réelle. Les opérations
indépendantes doivent pouvoir continuer ; ne pas confondre cette coordination locale
au Runtime avec un verrou entre des processus autonomes.

## Produit déjà intégré

Pour une mise à jour plutôt qu’un nouveau Tool, suivre [UpdateExistingProducts.md](UpdateExistingProducts.md).


## Native communication (Core 0.11.0)

Read [NativeCommunication.md](NativeCommunication.md). Use the platform Core wheel
containing CyMCPSDK C++ communication; source builds must compile Native/ first.
Do not add the Python MCP runtime or copy an old CLI/HTTP/MCP implementation.
Keep the Tool handlers, manifest, task files and standalone UI integration.
CLI `invoke` tasks are temporary; export wanted files with `--export-dir` or ExportJob.


## Effective AI capability discovery (0.11.0)

Before starting the runtime, call `cytools_core.communication.register_operations(runtime)`.
The read-only `ai_communication_status` operation reports the actually loaded native
Core/CyMCPSDK versions, lifecycle rules and, with `includeOperations: true`, the
complete effective operation schemas, permissions and resources. It does not start
a server, call a provider or grant permissions. The scaffold includes this registration.
MCP catalogues are paginated: follow `nextCursor` to inspect every operation.


## Profils MCP locaux — SDK 0.12.0

Lire [LocalAccess.md](LocalAccess.md). Intégrer CyMCPSDK au commit
`34d4bcae126bc83d1a2925b5047dac36e3d09d92` ou un descendant compatible vérifié.
Free est le choix initial sans jeton sur 127.0.0.1, avec toutes les opérations
enregistrées et validation conservée. Migrer les choix absents vers Free ; garder
les profils explicites Local contrôlé, Jeton seul et Protégé. Ne pas augmenter les
droits des clients CLI/embarqués ou des identités protégées lors de cette migration.
Le profil HTTP est une décision de l’hôte et les paramètres métier ne choisissent
jamais cette identité ou ce profil. Tester lecture/écriture sans jeton et refus de
Protégé sans jeton, puis les parcours CLI/chat existants, sans workflow GitHub.
