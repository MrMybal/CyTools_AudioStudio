#include <cytools/communication.hpp>
#include <cstdlib>
#include <iostream>
int main(int argc,char** argv){
    if(argc==1){std::cout<<cytools_native_info()<<std::endl;return 0;}
    const auto token=std::getenv("CYTOOLS_TOKEN");
    try{
        if(argc==3 && std::string(argv[1])=="--mcp"){
            cymcp::McpClient client(argv[2],token?token:"");
            client.connect();
            auto result=client.call_tool("cy_describe",cytools::Json::object());
            std::cout<<result.dump()<<std::endl;
            return result.value("isError",false)?1:0;
        }
        auto result=cytools::Communication::http_call(argv[1],token?token:"",
            {{"protocolVersion","1.0"},{"id",1},{"method","DescribeTool"},{"params",cytools::Json::object()}});
        std::cout<<result.dump()<<std::endl;return result.contains("error")?1:0;
    }catch(const cymcp::Error& e){
        std::cerr<<cytools::Json{{"error",{{"code",e.code},{"message",e.what()}}}}.dump()<<std::endl;return 1;
    }
}
